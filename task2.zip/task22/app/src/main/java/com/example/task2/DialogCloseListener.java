package com.example.task2;

import android.content.DialogInterface;

public interface DialogCloseListener {
    void handleDialogClose(DialogInterface dialog);
}